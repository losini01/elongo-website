
// script.js
// Exemple d'interaction simple : affichage d'un message de bienvenue
window.addEventListener('DOMContentLoaded', () => {
    console.log('Site chargé avec succès !');
});
